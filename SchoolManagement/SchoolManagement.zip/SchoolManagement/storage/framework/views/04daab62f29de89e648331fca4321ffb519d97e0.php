<?php $__env->startSection('content'); ?>
            <div class="page-content">
                <div class="row">
                    <div class="col-lg-10">
                        <div class="portlet">
                            <div class="portlet-header">
                                <div class="caption">Input data</div>
                                    <form method="POST" action="<?php echo e(route('schoolInsert')); ?>" role="form" id="formId" class="form-horizontal form-separated">

                                    <?php echo e(csrf_field()); ?>

                                        <div class="form-group">
                                            <label class="col-md-2 control-label">SchoolName</label>

                                            <div class="col-md-4">
                                                <input type="text" name="school" id="schoolname" class="form-control" required/>
                                            </div>
                                            <button  class="btn btn-primary">Add</button>
                                            <!-- <a href="<?php echo e(route('schoolAdd')); ?>" class="btn btn-primary">Add</a> -->
                                        </div>
                                    </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-10">
                        <div class="portlet">
                            <div class="portlet-header">
                                <div class="caption">Input data</div>
                                <div class="tools">
                                    <i class="fa fa-chevron-up"></i>
                                    <i data-toggle="modal" data-target="#modal-config" class="fa fa-cog"></i>
                                    <i class="fa fa-refresh"></i>
                                    <i class="fa fa-times"></i>
                                </div>
                                
                            </div>
                            <div class="portlet-body">
                                <form method="POST" action="<?php echo e(route('newData')); ?>" role="form" class="form-horizontal form-separated">
                                <?php echo e(csrf_field()); ?>

                                    <div class="form-bodyhelp">
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">SchoolName</label>

                                            <div class="col-md-6">
                                                <!-- <input id="schoolname" type="text" name="schoolname" class="form-control"/> -->
                                                <select type="text" name="schoolname" class="form-control" placeholder="SchoolName" required>
                                                        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option><?php echo e($data->school); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group"><label class="col-md-3 control-label" >Year</label>

                                            <div class="col-md-6">
                                                <!-- <input type="text" name="week" class="form-control"/> -->
                                                    <?php
                                                        $date=date('Y-m-d');
                                                        $date_array = explode('-', $date);
                                                        $year = $date_array[0];
                                                    ?>
                                                    <select type="text" name="year" id="year" class="form-control" placeholder="Year" required>

                                                            <?php for($yy = 1990; $yy <= $year; $yy++): ?> 
                                                            {
                                                                <?php if($yy==$year): ?>
                                                                    <option selected><?php echo e($yy); ?></option>
                                                                <?php else: ?>
                                                                    <option><?php echo e($yy); ?></option>
                                                                <?php endif; ?>
                                                            }
                                                            <?php endfor; ?>
                                                    </select>
                                            </div>
                                        </div>


                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Month</label>

                                            <div class="col-md-6">
                                                <!-- <input type="text" name="month" class="form-control" placeholder="Month" required/> -->


                                                <select type="text" name="month" id="month" class="form-control" placeholder="Month" required>

                                                    <?php for($month = 1; $month <= 12; $month++): ?> 
                                                        <option value="<?php echo e($month); ?>"><?php echo e($month); ?></option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group"><label class="col-md-3 control-label">Week</label>

                                            <div class="col-md-6">
                                                <!-- <input type="text" name="year" class="form-control" placeholder="Year" required/> -->
                                                
                                                <select type="text" id="week" name="week" class="form-control" placeholder="Wear" required>

                                                    <?php for($ww = 1; $ww <= 54; $ww++): ?> 
                                                        <option value="<?php echo e($ww); ?>"><?php echo e($ww); ?></option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>
                                        </div>
                                        

                                        
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Electricity Euro</label>

                                            <div class="col-md-6">
                                                <input type="text" name="electricity_euro" class="form-control" placeholder="Electricity Euro" required/>

                                            </div>
                                        </div>
                                        <div class="form-group"><label class="col-md-3 control-label">Electricity KWH</label>

                                            <div class="col-md-6">
                                                <input type="text" name="electricity_kwh" class="form-control" placeholder="Electricity_KWH" required/>
                                            </div>
                                        </div>

                                        <div class="form-group"><label class="col-md-3 control-label">Heating Euro</label>

                                            <div class="col-md-6">
                                                <input type="text" name="heating_euro" class="form-control" placeholder="Heating_Euro" required/>
                                            </div>
                                        </div>

                                        <div class="form-group"><label class="col-md-3 control-label">Heating KWH</label>

                                            <div class="col-md-6">
                                                <input type="text" name="heating_kwh" class="form-control" placeholder="Heating_KWH" required/>

                                            </div>
                                        </div>
                                        <div class="form-group"><label class="col-md-3 control-label">Water Euro</label>

                                            <div class="col-md-6">
                                                <input type="text" name="water_euro" class="form-control" placeholder="Water_Euro" required/>

                                            </div>
                                        </div>
                                        <div class="form-group"><label class="col-md-3 control-label">water Litre</label>

                                            <div class="col-md-6">
                                                <input type="text" name="water_litre" class="form-control" placeholder="Water_Litre" required/>
                                            </div>
                                        </div>                                        
                                    </div>

                                    <div class="form-actions">
                                        <div class="col-md-offset-3 col-md-9">
                                            <button type="submit" class="btn btn-primary">Add</button>
                                            &nbsp;
                                            <button type="button" class="btn default">Cancel</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script'); ?>

<script>

    $(function()
    {
        $('#addButton').on('click',function(e)
        {
           
            alert('a');
            $.ajaxSetup
            ({
                header:$('meta[name="_token"]').attr('content')
            })

            e.preventDefault(e);

            $.ajax({
                type:"POST",
                url:'/create/school',
                data:$(this).serialize(),
                dataType: 'json',
                success: function(data)
                {
                    console.log(data);
                    alert('ok');
                },
                error: function(data)
                {

                }
                
           });
        });
    });
</script>



<script>
    $(document).ready(function ($) 
    {
        $('#year').on('change',function()
        { 
            var selectedyear=$('#year').val();
            var selectedmonth=$('#month').val();
            function ISO8601_week_no(dt) 
            {
                var tdt = new Date(dt.valueOf());
                var dayn = (dt.getDay() + 6) % 7;
                tdt.setDate(tdt.getDate() - dayn + 3);
                var firstThursday = tdt.valueOf();
                tdt.setMonth(0, 1);
                if (tdt.getDay() !== 4) 
                {
                    tdt.setMonth(0, 1 + ((4 - tdt.getDay()) + 7) % 7);
                }
                    return 1 + Math.ceil((firstThursday - tdt) / 604800000);
            }

            // dt = new Date();
            // console.log(ISO8601_week_no(dt));

            dt1 = new Date(selectedyear, selectedmonth, 1);
            dt2 = new Date(selectedyear, parseInt(selectedmonth)+1, 1);
             // alert(ISO8601_week_no(dt1))
             // alert(ISO8601_week_no(dt2))

             $('#week').empty();

             var beforeM=ISO8601_week_no(dt1);
             var afterM=ISO8601_week_no(dt2);

             for( var i=beforeM;i<afterM;i++ )
             {
                $('#week').append('<option value="'+i+'">'+i+'</option>')
             }
        });


        $('#month').on('change',function()
        { 
            var selectedyear=$('#year').val();
            var selectedmonth=$('#month').val();
            function ISO8601_week_no(dt) 
            {
                var tdt = new Date(dt.valueOf());
                var dayn = (dt.getDay() + 6) % 7;
                tdt.setDate(tdt.getDate() - dayn + 3);
                var firstThursday = tdt.valueOf();
                tdt.setMonth(0, 1);
                if (tdt.getDay() !== 4) 
                {
                    tdt.setMonth(0, 1 + ((4 - tdt.getDay()) + 7) % 7);
                }
                    return 1 + Math.ceil((firstThursday - tdt) / 604800000);
            }
            dt = new Date();
            console.log(ISO8601_week_no(dt));
            dt1 = new Date(selectedyear, selectedmonth, 1);
            dt2 = new Date(selectedyear, parseInt(selectedmonth)+1, 1);
             

             $('#week').empty();

             var beforeM=ISO8601_week_no(dt1);
             var afterM=ISO8601_week_no(dt2);

             for( var i=beforeM;i<afterM;i++ )
             {
                $('#week').append('<option value="'+i+'">'+i+'</option>')
             }
        });
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>