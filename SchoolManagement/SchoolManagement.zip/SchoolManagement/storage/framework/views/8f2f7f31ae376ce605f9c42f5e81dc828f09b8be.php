<?php $__env->startSection('content'); ?>
            <div class="page-content">
                <div class="row">
                    <div class="col-lg-10">
                        <div class="portlet">
                            <div class="portlet-header">
                                <div class="caption">Input data</div>
                                <!-- <div class="tools">
                                    <i class="fa fa-chevron-up"></i>
                                    <i data-toggle="modal" data-target="#modal-config" class="fa fa-cog"></i>
                                    <i class="fa fa-refresh"></i>
                                    <i class="fa fa-times"></i>
                                </div> -->

                                <div class="form-group">
                                    <label class="col-md-3 control-label" style="margin-top: 20px">SchoolName</label>

                                    <div class="col-md-6"><input class="form-control" style="margin-top: 20px"/></div>
                                </div>
                                <div class="tools">
                                    <button type="submit" class="btn btn-primary">Add</button>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <form method="POST"  role="form" class="form-horizontal form-separated">

                                <?php echo e(csrf_field()); ?>

                                    <div class="form-bodyhelp">
                                        <div class="form-group"><label class="col-md-3 control-label">SchoolName</label>

                                            <div class="col-md-6">
                                                <input class="form-control"/>
                                            </div>
                                        </div>
                                        <div class="form-group"><label class="col-md-3 control-label">Year</label>

                                            <div class="col-md-6"><input class="form-control"/>

                                            </div>
                                        </div>
                                        <div class="form-group"><label class="col-md-3 control-label">Week</label>

                                            <div class="col-md-6">
                                                <!-- <input class="form-control"/> -->
                                                <select multiple="multiple" class="form-control">
                                                    <option>Option 1</option>
                                                    <option>Option 2</option>
                                                    <option>Option 3</option>
                                                    <option>Option 4</option>
                                                    <option>Option 5</option>
                                                    <option>Option 6</option>
                                                    <option>Option 7</option>
                                                    <option>Option 8</option>
                                                    <option>Option 9</option>
                                                    <option>Option 10</option>
                                                    <option>Option 11</option>
                                                    <option>Option 12</option>
                                                    <option>Option 13</option>
                                                    <option>Option 14</option>
                                                    <option>Option 15</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group"><label class="col-md-3 control-label">Month</label>

                                            <div class="col-md-6"><input class="form-control"/>

                                            </div>
                                        </div>
                                        <div class="form-group"><label class="col-md-3 control-label">Electricity Euro</label>

                                            <div class="col-md-6"><input class="form-control"/>

                                            </div>
                                        </div>
                                        <div class="form-group"><label class="col-md-3 control-label">Electricity KWH</label>

                                            <div class="col-md-6"><input class="form-control"/>
                                            </div>
                                        </div>

                                        <div class="form-group"><label class="col-md-3 control-label">Heating Euro</label>

                                            <div class="col-md-6"><input class="form-control"/>
                                            </div>
                                        </div>

                                        <div class="form-group"><label class="col-md-3 control-label">Heating KWH</label>

                                            <div class="col-md-6"><input class="form-control"/>

                                            </div>
                                        </div>
                                        <div class="form-group"><label class="col-md-3 control-label">Water Euro</label>

                                            <div class="col-md-6"><input class="form-control"/>

                                            </div>
                                        </div>
                                        <div class="form-group"><label class="col-md-3 control-label">water Litre</label>

                                            <div class="col-md-6"><input class="form-control"/>
                                            </div>
                                        </div>                                        
                                    </div>

                                    <div class="form-actions">
                                        <div class="col-md-offset-3 col-md-9">
                                            <button type="submit" class="btn btn-primary">Add</button>
                                            &nbsp;
                                            <button type="button" class="btn default">Cancel</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>