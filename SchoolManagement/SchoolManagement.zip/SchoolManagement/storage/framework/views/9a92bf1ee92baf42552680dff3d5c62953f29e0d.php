<?php $__env->startSection('content'); ?>

    <div class="portlet">
        <div class="portlet-header">
            <div class="caption">Input data</div>
                <form method="POST" action="<?php echo e(route('schoolInsert')); ?>" role="form" class="form-horizontal form-separated">

             
                    <div class="form-group">
                        <label class="col-md-2 control-label">SchoolName</label>

                        <div class="col-md-4">
                            <!-- <input type="text" name="school" class="form-control"/> -->
                        </div>
                        <!-- <button type="submit" class="btn btn-primary">Add</button> -->
                        <a href="<?php echo e(route('schoolAdd')); ?>" class="btn btn-primary">Add</a>
                    </div>
                </form>
            </div>

        </div>
            
       
        <div class="portlet-body">
        <div id="flip-scroll">
            <table class="table table-bordered table-striped table-condensed cf">
                <thead class="cf">
                
                    <th>No</td>
                    <th>schoolName</td>
                    <th class="numeric">Year</th>
                    <th class="numeric">Week</th>
                    <th class="numeric">Month</th>
                    <th class="numeric">Electricity_euro</th>
                    <th class="numeric">Electricity_kwh</th>
                    <th class="numeric">Heating_euro</th>
                    <th class="numeric">Heating_kwh</th>
                    <th class="numeric">water_euro</th>
                    <th class="numeric">Water_litre</th>
                    <th class="numeric">action</th>
                
                </thead>
                <tbody>
                <?php $__currentLoopData = $schoolDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schoolData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($schoolData->id); ?></td>
                    <td><?php echo e($schoolData->schoolname); ?> </td>
                    <td class="numeric"><?php echo e($schoolData->year); ?></td>
                    <td class="numeric"><?php echo e($schoolData->week); ?></td>
                    <td class="numeric"><?php echo e($schoolData->month); ?></td>
                    <td class="numeric"><?php echo e($schoolData->electricity_euro); ?></td>
                    <td class="numeric"><?php echo e($schoolData->electricity_kwh); ?></td>
                    <td class="numeric"><?php echo e($schoolData->heating_euro); ?></td>
                    <td class="numeric"><?php echo e($schoolData->heating_kwh); ?></td>
                    <td class="numeric"><?php echo e($schoolData->water_euro); ?></td>
                    <td class="numeric"><?php echo e($schoolData->water_litre); ?></td>
                    <td class="numeric"></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>