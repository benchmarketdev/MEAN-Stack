export class School {

    id?: number;
    name: string;

  }
  